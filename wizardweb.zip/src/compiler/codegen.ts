import type { Stmt } from './parser';
export function codegen(stmts: Stmt[]): string {
  const out: string[] = [];
  for (const s of stmts) {
    if (s.kind === 'open') {
      out.push(`const ${s.alias} = (window as any).realms['${s.ns}'];`);
    } else {
      const args = s.args.map(a => typeof a === 'string' ? JSON.stringify(a) : a).join(',');
      out.push(`${s.alias}.${s.fn}(${args});`);
    }
  }
  return out.join('\n');
}